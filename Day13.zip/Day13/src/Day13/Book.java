package Day13;
public class Book {
//String title;
//String author;

//public Book(String t) {
	//title=t; author="작자미싱";
//}
//public Book (String t,String a){
	//title=t; author=a;
	
//}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
//Book littlePrince= new Book("어린왕자","생택쥐페리");
//Book loveStory= new Book("춘향전");
//System.out.println(littlePrince.title+""+littlePrince.author);
//Object loveStroy;
//System.out.println(loveStroy.title+""+loveStroy.author);
	}

}

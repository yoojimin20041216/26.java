package Day13;

// Circle
class Circle{
	public int radius;
	public String name;

public Circle() {
	this(0,"");
	//radius=10;
	//name="";
}
public Circle(int radius) {
	this(radius,"불고기피자");
}
// 인자(매개변수) 생성기....
public Circle(int radius,String name) {
	this.radius=radius;
	this.name=name;
}
public class Pizza {

	public double getArea() {
		return 3.14*radius*radius;
	}
	public static void main(String[] args) {
	
		// TODO Auto-generated method stub
// 1.래퍼런스 변수 pizza 선언
Circle pizza,pizza2;
// 2.Circle 객체 생성
pizza=new Circle();
pizza2= new Circle(10,"치즈피자");
// 3. 피자의 반지름을 10으로 설정
//pizza.radius=10;
// 4.피자의 이름을 불고기 피자로 설정
//pizza.name="불고기피자";
// 5.피자의 면적 메소드 호출하여 알아내기
System.out.println(pizza.name+"인 원의 면적은"+pizza.getClass());
System.out.println(pizza2.name);
		
//Circle donut;
//Circle dount = new Circle();
//dount.radius=5;
//dount.name="자바도넛";
//System.out.println(dount.name+"인 원의 면적은"+dount.getClass());
	}

}

}


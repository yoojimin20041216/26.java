package Day13;

public class Human2 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
}
}
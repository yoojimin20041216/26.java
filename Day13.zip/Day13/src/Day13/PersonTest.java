package Day13;

public class PersonTest {


	public static void main(String[] args) {
		// TODO Auto-generated method stub
Human hong = new Human();
//hong.name ="홍길동";
//hong.age=20;
//hong.abc='A';

hong.밥먹기();
hong.운동하기("헬스");
	}

}

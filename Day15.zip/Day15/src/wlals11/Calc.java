package wlals11;

public class Calc {

	public int calclate(int x, int y) {
		return x+y;
	}
	

}

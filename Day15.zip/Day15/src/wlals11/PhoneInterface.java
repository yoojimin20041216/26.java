package wlals11;

 interface PhoneInterface {
 // 상수
	final int TIMEOUT=10000;
	void sendCall(); // 추상메소드
	void receiveCall();
	
	default void printLogo() {
		System.out.println("** phone");
	}
	

}

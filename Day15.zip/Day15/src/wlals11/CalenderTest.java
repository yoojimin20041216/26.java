package wlals11;
import java.util.*;
public class CalenderTest {

	public static void main(String[] args) {
		Calendar calendar= Calendar.getInstance();
        System.out.println("현재 날짜");
        System.out.print(calendar.get(Calendar.YEAR) + "년");
        System.out.print(calendar.get(Calendar.MONTH) + 1 + "월");
        System.out.print(calendar.get(Calendar.DATE) + "일");
        System.out.println(calendar.get(Calendar.HOUR)+"시간");
        System.out.println(calendar.get(Calendar.SECOND)+"초");
	}

}

package wlals11;
import java.awt.*;
import javax.swing.*;
 
public class BorderLayoutTest extends JFrame {
    
	private static final String EAST = null;
	private static final String WEST = null;
	private static final String NORTH = null;
	private static final String SOUTH = null;
	private static final String CENTER = null;

	public BorderLayoutTest() {
		setSize(250,250);
		setTitle("세번째 프레임");
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JButton btn1=new JButton("add");
		JButton btn2=new JButton("sub");
		JButton btn3=new JButton("mul");
		JButton btn4=new JButton("div");
		JButton btn5=new JButton("center");
		
		this.add(btn3, BorderLayoutTest.EAST);
		this.add(btn4, BorderLayoutTest.WEST);
		this.add(btn1, BorderLayoutTest.NORTH);
		this.add(btn2, BorderLayoutTest.SOUTH);
		this.add(btn5, BorderLayoutTest.CENTER);
	}
	
	private void setDefaultCloseOperation(String exitOnClose) {
		// TODO Auto-generated method stub
		
	}

	private void setVisible(boolean b) {
		// TODO Auto-generated method stub
		
	}

	private void setTitle(String string) {
		// TODO Auto-generated method stub
		
	}

	private void setSize(int i, int j) {
		// TODO Auto-generated method stub
		
	}

	private void add(JButton btn3, String east2) {
		// TODO Auto-generated method stub
		
	}

	public static void main(String[] args) {
		new BorderLayout();

	}

}

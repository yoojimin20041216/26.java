package wlals11;
import javax.swing.*;
import java.awt.*;

public class MyFrame2 extends JFrame {
  public MyFrame2() {
	  setTitle("ContentPane과JFrame");
	  setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	  Container contentPane= getContentPane();
	  contentPane.setBackground(Color.ORANGE);
	  contentPane.setLayout(new FlowLayout());
	  contentPane.add(new JButton("OK"));
	  contentPane.add(new JButton("Cancel"));
	  contentPane.add(new JButton("Ignore"));
	  setSize(300, 150);
	  setVisible(true);
  }
	private void setVisible(boolean b) {
	// TODO Auto-generated method stub
	
}
	private void setSize(int i, int j) {
	// TODO Auto-generated method stub
	
}
	private Container getContentPane() {
	// TODO Auto-generated method stub
	return null;
}
	private void setDefaultCloseOperation(String exitOnClose) {
	// TODO Auto-generated method stub
	
}
	private void setTitle(String string) {
	// TODO Auto-generated method stub
	
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new MyFrame2();
	}

}

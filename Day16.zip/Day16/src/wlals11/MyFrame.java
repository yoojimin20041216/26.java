package wlals11;
import javax.swing.*;
 
 public class MyFrame extends JFrame{
 public MyFrame() { 
	 setTitle("300x300 스윙프레임만들기");
	 setSize(300,300); // 프레임크기300x300
	 setVisible(true); // 프레임출력
	
 }
 
 
 private void setVisible(boolean b) {
	// TODO Auto-generated method stub
	
}


 private void setSize(int i, int j) {
	// TODO Auto-generated method stub
	
}


 private void setTitle(String string) {
	// TODO Auto-generated method stub
	
}


 public static void main(String[] args) {
	 MyFrame frame = new MyFrame(); 
 }
 }
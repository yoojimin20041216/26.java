package day02;

public class DataTypeTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
// 1.기본형 변수 선언
		boolean isTrue;
		int age;
		double height, weight; 
		
		// 2. 변수 초기화
		isTrue = false;
		age = 23;
		height = 187.1;
		weight = 81.1;
		
		// 2. 래퍼랜스형 - 3개 (배열, 클래스, 인터페이스)
		String name="유지민";
		//name ="유지민";
		String s = new String(" 유지민");
		DataTypeTest dtt = new  DataTypeTest();
		// 주소 addr
		String a = new String("인천광역시");
		// 3. 변수 값 출력하기
		System.out.println(isTrue);
		System.out.println("나이;"+age);
		System.out.println("키;"+height);
		System.out.println("몸무게;"+weight);
		System.out.println("이름;"+name);
		
	}

}

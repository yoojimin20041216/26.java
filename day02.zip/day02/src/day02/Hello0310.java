package day02;

public class Hello0310 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
// print 계열 메소드를 이용해 자바로 하고 싶은 것 작성하여 출력 하기 
		    
	    
	}

}

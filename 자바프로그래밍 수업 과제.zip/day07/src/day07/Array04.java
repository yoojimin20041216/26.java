package day07;

public class Array04 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String names[]= {"사과","바나나","딸기","복숭아","포도"};
try {
for(int i=0; i<6;i++) {
	System.out.println(names[i]);
}
} catch(ArrayIndexOutOfBoundsException a) {
	a.printStackTrace();
}
	}

}

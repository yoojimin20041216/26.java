package day07;

public class Array03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int sum[]= {1,2,3,4,5};
int Sum=0;
for(int n:Sum) {
	Sum=n;
}
System.out.println(Sum);
	}

}

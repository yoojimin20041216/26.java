package day07;
import java.util.Scanner;
public class Array01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner= new Scanner(System.in);
int intArray[]= new int[5];
int Max=0;
System.out.println("양수 5개를 입력하세요.");
for(int i=0; i<5; i++) {
	intArray[i] = scanner.nextInt();
	if(intArray[i]>Max) 
		Max=intArray[i];
	}
System.out.println("가장 큰수는"+Max+"입니다.");
scanner.close();
}
}
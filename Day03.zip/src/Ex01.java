
public class Ex01 extends Day03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

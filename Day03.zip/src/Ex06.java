import java.util.Scanner;
public class Ex06 {
char grade;
Scanner scanner= new Scanner(System.in);
System.out.println("점수를 입력하세요."); // 점수읽기
int score = scanner.nextInt();
if(score >=90) // score 90점 이상
	grade ='A';
else if(score >=80)
grade='B';
else if(score >=70)
	grade='C';
else if(score >=60)
	grade='D';
System.out.println("학점은 "+ grade+"입니다.");

scanner.close();

}
}

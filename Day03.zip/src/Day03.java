import java.util.Scanner;

public class Day03 {
// improt
	
	public static void main(String[] args) {
		// TODO Auto-generated method 
		int age; // 변수 선언
		String name = new String();
		// 변수 초기화 
		age = 20;
		name ="유지민";
		System.out.println("나야;" + age);
		System.out.println("이름;" + age);
		
		// scanner 객체 생성
		Scanner scan= new Scanner(System.in);
		System.out.println("나이를 입력하세요;");
		age = scan.nextInt();
		System.out.println("이름을 입력하세요;");
		scan.next();
		double height;
		System.out.println("키을 입력하세요;");
		height =scan. nextDouble();
		System.out.println("나이;" + age);
		System.out.println("이름;" + age);

		
		
		
	}

}
